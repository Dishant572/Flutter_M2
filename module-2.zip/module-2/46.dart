// 46.  Create a program using List
void main() {
  var list1 = [10, 11, 12, 13, 14, 15];
  print(list1);
}
