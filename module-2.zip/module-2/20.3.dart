/*20. Looping Programs
3).Write a program to print the 100 to 81 using do while loop */

void main() {
  var i;

  i = 100;
  do {
    print("$i");
    i--;
  } while (i >= 81);
}
