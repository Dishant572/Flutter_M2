// 47.Create a program using Set

void main() {
  Set set1 = {};

  set1.add(10);
  set1.add(20);

  for (int i in set1) {
    print(i);
  }
}
